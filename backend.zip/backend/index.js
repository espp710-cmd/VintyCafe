const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// TEST ROOT
app.get("/", (req, res) => {
  res.send("Backend Vinty jalan cuy");
});

// 🔥 LOGIN ROUTE (INI YANG LU BUTUH)
app.post("/api/auth/login", (req, res) => {
  const { username, password } = req.body;

  if (username === "admin" && password === "admin123") {
    return res.json({
      success: true,
      token: "vinty-token",
      user: {
        username: "admin",
        role: "admin"
      }
    });
  }

  res.status(401).json({
    success: false,
    message: "Username atau password salah"
  });
});

app.listen(3000, () => {
  console.log("Server jalan di http://localhost:3000");
});